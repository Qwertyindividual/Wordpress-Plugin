<?php
echo "Please insert this shortcode anywhere on your page: [donate]My Text here[/donate]";